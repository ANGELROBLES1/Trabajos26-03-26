class Nodo:
    def __init__(self, valor, hijos=None):
        self.valor = valor
        self.hijos = hijos if hijos else []

    def imprimir(self, nivel=0):
        print("  " * nivel + self.valor)
        for hijo in self.hijos:
            hijo.imprimir(nivel + 1)


class ParserGeneral:
    def __init__(self, gramatica, tokens):
        self.gramatica = gramatica
        self.tokens = tokens
        self.pos = 0

    def actual(self):
        if self.pos < len(self.tokens):
            return self.tokens[self.pos]
        return None

    def consumir(self, token):
        if self.actual() == token:
            self.pos += 1
        else:
            raise Exception("Error sintactico se esperaba " + token + " pero se encontro " + str(self.actual()))

    def parse(self, simbolo):
        if simbolo not in self.gramatica:
            raise Exception("Error simbolo no definido " + simbolo)

        producciones = self.gramatica[simbolo]

        for prod in producciones:
            pos_backup = self.pos
            hijos = []
            error = False

            if prod == ["epsilon"]:
                return Nodo(simbolo, [])

            for token in prod:
                if token in self.gramatica:
                    try:
                        nodo = self.parse(token)
                        hijos.append(nodo)
                    except:
                        error = True
                        break
                else:
                    if self.actual() == token:
                        hijos.append(Nodo(token))
                        self.consumir(token)
                    else:
                        error = True
                        break

            if not error:
                return Nodo(simbolo, hijos)

            self.pos = pos_backup

        raise Exception("Error no se pudo derivar " + simbolo)


def tokenizar(cadena):
    tokens = []
    i = 0

    while i < len(cadena):
        c = cadena[i]

        if c.isdigit():
            while i < len(cadena) and cadena[i].isdigit():
                i += 1
            tokens.append("num")
            continue

        elif c == '+':
            tokens.append("opsuma")
        elif c == '-':
            tokens.append("opsuma")
        elif c == '*':
            tokens.append("opmul")
        elif c == '(':
            tokens.append("pari")
        elif c == ')':
            tokens.append("pard")
        elif c == ' ':
            i += 1
            continue
        else:
            raise Exception("Error caracter no valido " + c)

        i += 1

    return tokens


def leer_archivo(nombre):
    with open(nombre, "r") as f:
        contenido = f.read()

    if "%%" not in contenido:
        raise Exception("Error falta separador %%")

    partes = contenido.split("%%")

    reglas = partes[0].strip().split("\n")
    cadena = partes[1].strip()

    gramatica = {}

    for regla in reglas:
        izquierda, derecha = regla.split("->")
        izquierda = izquierda.strip()
        producciones = derecha.split("|")

        gramatica[izquierda] = []

        for prod in producciones:
            tokens = prod.strip().split()
            gramatica[izquierda].append(tokens)

    tokens_entrada = tokenizar(cadena)

    return gramatica, tokens_entrada


if __name__ == "__main__":
    archivo = "entrada.txt"

    try:
        gramatica, tokens = leer_archivo(archivo)

        parser = ParserGeneral(gramatica, tokens)

        simbolo_inicial = list(gramatica.keys())[0]

        arbol = parser.parse(simbolo_inicial)

        if parser.pos != len(tokens):
            raise Exception("Error tokens sobrantes")

        print("Arbol de sintaxis generado")
        arbol.imprimir()

    except Exception as e:
        print(str(e))
